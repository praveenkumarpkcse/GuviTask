<?php

/**
 *  Connection for Database 
 *
 **/
require "Database.php";

/**
 *  Data from the Request  
 *
 **/
$inputData = file_get_contents("php://input");

/**
 *  Validating the InputData is not empty
 *
 **/
if(isset($inputData) && !empty($inputData))
{
	$requestData = json_decode($inputData);
	
	/**
 	 * anitize the Data before storing in DB
     *
     **/
	$NickName    = mysqli_real_escape_string ( $conn , trim($requestData->inputNickName));
	$DOB         = mysqli_real_escape_string ( $conn , trim($requestData->inputDob));
	$A_PhoneNo   = mysqli_real_escape_string ( $conn , trim($requestData->inputPhoneNo));
	$Department  = mysqli_real_escape_string ( $conn , trim($requestData->inputDep));
	

	$sql = "INSERT INTO `profileData` (`NickName`,`DOB`,`Additional PhoneNo`,`Department`) VALUES ('{$NickName}','{$DOB}','{$A_PhoneNo}','{$Department}')";
	
	if(mysqli_query($conn,$sql))
	{
		http_response_code(201);
		$data = 'Y';
		echo json_encode($data);
	} 
	else
	{
		http_response_code(422);
	}
}



?>