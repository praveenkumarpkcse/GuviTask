<?php

/**
 *  Connection for Database 
 *
 **/
require "Database.php";

/**
 *  Data from the Request  
 *
 **/
$inputData = file_get_contents("php://input");

/**
 *  Validating the InputData is not empty
 *
 **/

if(isset($inputData) && !empty($inputData))
{
	$requestData = json_decode($inputData);

	
	/**
 	 *  Sanitize the Data before storing in DB
     *
     **/
	$profileName = trim($requestData->inputName);
	$userName    = trim($requestData->inputEmail);
	$password    = trim($requestData->inputPassword);
	$phoneNumber = trim($requestData->inputPhoneNo);


	$sql = "INSERT INTO `LoginDetails` (`profileName`,`userName`,`password`,`phoneNumber`) VALUES ('{$profileName}','{$userName}','{$password}','{$phoneNumber}')";
	
	if(mysqli_query($conn,$sql))
	{
		http_response_code(201);
		$data = [
			'id' => mysqli_insert_id($conn),
			'profileName' => $profileName ,
			'userName' =>$userName,
			'password'=>$password,
			'phoneNumber'=>$phoneNumber
		];

		echo json_encode($data);

		/**
 	     *  Generating the file of userData in json formate
         *
         **/

		$fp = fopen('results.json', 'w');
		fwrite($fp, json_encode($data));
		fclose($fp);
	} 
	else
	{
		http_response_code(422);
	}
}



?>