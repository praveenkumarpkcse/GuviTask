<?php

 /**
  * Headers for BackEnd 
  *
  **/
 header("Access-Control-Allow-Origin  : * ");
 header("Access-Control-Allow-Methods : GET , POST , DELETE , PUT ");
 header("Access-Control-Allow-Headers : Origin , X-Request-with , Content-Type , Accept ");

 /**
  * Define Database Connectivity 
  *
  **/

 define( "DB_HOST","localhost");
 define( "DB_USER", "root");
 define( "DB_PWD" , "Error@404");
 define( "DB_DBNAME" , "Details");

 /**
  * Database Connectivity 
  *
  **/
 
 function connect()
 {
 	$connect = mysqli_connect(DB_HOST,DB_USER,DB_PWD,DB_DBNAME);

 	if(mysqli_connect_error($connect))
 	{
 		die("Failed to connect Database".mysqli_connect_error());
 	}

 	mysqli_set_charset($connect,'utf8');

 	return $connect;
 }

 $conn = connect();


?>