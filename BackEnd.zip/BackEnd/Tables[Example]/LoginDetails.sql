INSERT INTO `LoginDetails` (`id`, `profileName`, `userName`, `password`, `phoneNumber`) VALUES
(11,	'Praveen',	'pk@pk.com',	'123',	9853221),
(12,	'sdf',	'pk@pk.com',	'123',	123123),
(13,	'Praveen',	'Praveenkumar@pk.com',	'1234',	987654331);
