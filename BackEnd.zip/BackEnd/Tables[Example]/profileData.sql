INSERT INTO `profileData` (`id`, `NickName`, `DOB`, `Additional PhoneNo`, `Department`) VALUES
(11,	'Praveen',	'2020-10-28',	'789798',	'Computer');
