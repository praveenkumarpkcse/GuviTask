<?php

/**
 *  Connection for Database 
 *
 **/
require "Database.php";

/**
 *  Data from the Request  
 *
 **/
$inputData = file_get_contents("php://input");

/**
 *  Validating the InputData is not empty
 *
 **/
if(isset($inputData) && !empty($inputData))
{
	$requestData = json_decode($inputData);

	/**
 	 *  Sanitize the Data before storing in DB
     *
     **/
	$userName = mysqli_real_escape_string ( $conn , trim($requestData->inputEmail));
	$password = mysqli_real_escape_string ( $conn , trim($requestData->inputPassword));

	$sql ="SELECT * from `LoginDetails` WHERE userName ='{$userName}' AND password = '{$password}'";

	if($result = mysqli_query($conn,$sql))
	{
		if(mysqli_fetch_assoc($result) >= 1)
		{
			$data = 'Y';
			echo json_encode($data);
		}
	}
	else
	{
		http_response_code(404);
	}
}

?>