import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { APICallService } from '../apicall.service';
import { UserInput} from '../user-input';

@Component({
  selector: 'app-sigin',
  templateUrl: './sigin.component.html',
  styleUrls: ['./sigin.component.scss']
})
export class SiginComponent implements OnInit {


  /**
   * Declared variables 
   */
  siginForm: FormGroup;
  submitted = false;
  UserData = [];
  
  /**
   * 
   * @param fb 
   * @param router 
   * @param APICall 
   */
  constructor( private fb: FormBuilder,
               private router: Router,
               private APICall: APICallService) { }
  
               
  /**
   * Validating form at the time of loading page  
   */ 
  ngOnInit() {
    this.siginForm = this.fb.group({
      inputName :['',[Validators.required]],
      inputEmail: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.][a-zA-Z0-9-]{2,4}$')]],
      inputPassword: ['', [Validators.required]],
      inputPhoneNo:['',[Validators.required]]
    });

  }

  /**
   * Assigned formDetials to a variable   
   */ 
  get f() { return this.siginForm.controls; }
  
  /**
   * sigin function    
   */
  sigin()
  {
    this.submitted = true;
    if (this.siginForm.invalid) {
      return false;
    }
    this.APICall.createUser(this.siginForm.value).subscribe((UserInput:UserInput[])=>{
      this.UserData = UserInput;
      if(this.UserData!=null)
      alert("Successfully Stored in Database....!");
      this.router.navigate(['/login']);
    });
    
    if(this.UserData)
    {
      this.router.navigate(['/login']);
    }
  }
}
