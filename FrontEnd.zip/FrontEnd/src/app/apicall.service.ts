import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserInput}  from '../app/user-input';

@Injectable({
  providedIn: 'root'
})
export class APICallService {

  BackEndURL = 'http://127.0.0.1:8000';

  constructor(private httpCall : HttpClient) { }


  createUser(UserData:UserInput):Observable<UserInput[]>
  {
    return this.httpCall.post<UserInput[]>(`${this.BackEndURL}/CreateUser.php`,UserData);
  }

  loginUser(UserData:UserInput):Observable<UserInput[]>
  {
    return this.httpCall.post<UserInput[]>(`${this.BackEndURL}/loginUser.php`,UserData);
  }

  dashboardUser(UserData:UserInput):Observable<UserInput[]>
  {
    return this.httpCall.post<UserInput[]>(`${this.BackEndURL}/dashboard.php`,UserData);
  }

}
