import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { APICallService } from '../apicall.service';
import { UserInput} from '../user-input';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  /**
   * Declared variables 
   */

  dashboardForm: FormGroup;
  submitted = false;
  UserData = [];

  /**
   * 
   * @param fb 
   * @param router 
   * @param APICall 
   */

  constructor( private fb: FormBuilder,
               private APICall: APICallService) { }
  
  /**
   * Validating form at the time of loading page  
   */                
  ngOnInit() {
    this.dashboardForm = this.fb.group({
      inputNickName :['',[Validators.required]],
      inputDob: ['', [Validators.required]],
      inputPhoneNo: ['', [Validators.required]],
      inputDep:['',[Validators.required]]
    });
  }

  /**
   * Assigned formDetials to a variable   
   */ 
  get f() { return this.dashboardForm.controls; }

  /**
   * dashboard function    
   */
  dashboard()
  {
    this.submitted = true;
    if (this.dashboardForm.invalid) {
      return false;
    }
    this.APICall.dashboardUser(this.dashboardForm.value).subscribe((UserInput:UserInput[])=>{
      this.UserData = UserInput;
    });
  }

}
