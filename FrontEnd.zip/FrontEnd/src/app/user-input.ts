export class UserInput {
    id          : Number;
    profilename : String;
    email       : String;
    password    : String;
    dob         : Date;
    age         : Number;

}
