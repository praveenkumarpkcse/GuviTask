import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { APICallService } from '../apicall.service';
import { UserInput} from '../user-input';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  /**
   * Declared variables 
   */
  oldUserName = '';
  loginForm: FormGroup;
  submitted = false;
  UserData = [];
  
  /**
   * 
   * @param fb 
   * @param router 
   * @param APICall 
   */
  constructor( private fb: FormBuilder,
               private router:Router,
               private APICall : APICallService) { }

  /**
   * Retrieving Data from local Storage  
   */           
  ngOnInit() {
     
    this.loginForm = this.fb.group({
      inputEmail: ['', [Validators.required, Validators.email, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.][a-zA-Z0-9-]{2,4}$')]],
      inputPassword: ['', [Validators.required]]
    });

    if (localStorage.getItem('userName')) {  
      this.oldUserName = atob(localStorage.getItem('userName'));
    }
    if (localStorage.getItem('loginEmail')) {
      this.loginForm.patchValue({
        'inputEmail': atob(localStorage.getItem('loginEmail'))
      });
    }
  }

  /**
   * Assigned formDetials to a variable   
   */ 
  get f() { return this.loginForm.controls; }

  /**
   * Login function    
   */
  login() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return false;
    }
   this.APICall.loginUser(this.loginForm.value).subscribe((UserInput:UserInput[])=>{
   this.UserData = UserInput;
   if(this.UserData!=null)
     this.router.navigate(['/dashboard']);
   else
     alert("Invalid Credentials Try Again....!");
   });
  
  }
}
